# fnet-improved
An improved FNet forked from Hugging Face transformers
